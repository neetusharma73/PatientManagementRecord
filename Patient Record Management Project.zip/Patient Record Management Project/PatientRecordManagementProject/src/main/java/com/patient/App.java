package com.patient;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.List;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        SessionFactory factory = new Configuration().configure().buildSessionFactory();

        // DAOs
        PatientDAO patientDAO = new PatientDAO(factory);
        DoctorDAO doctorDAO = new DoctorDAO(factory);
        AppointmentDAO appointmentDAO = new AppointmentDAO(factory);
        PrescriptionDAO prescriptionDAO = new PrescriptionDAO(factory);

        Scanner sc = new Scanner(System.in);
        System.out.println("*Welcome to Patient Record Management System*\n");

        while (true) {
            System.out.println("Enter your choice:");
            System.out.println("1. Manage Patients");
            System.out.println("2. Manage Doctors");
            System.out.println("3. Manage Appointments");
            System.out.println("4. Manage Prescriptions");
            System.out.println("5. Exit the App");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    managePatients(sc, patientDAO);
                    break;
                case 2:
                    manageDoctors(sc, doctorDAO);
                    break;
                case 3:
                    manageAppointments(sc, appointmentDAO);
                    break;
                case 4:
                    managePrescriptions(sc, prescriptionDAO);
                    break;
                case 5:
                    System.out.println("Exiting from the app...");
                    sc.close();
                    factory.close();
                    System.exit(0);
                default:
                    System.out.println("Enter a valid choice!");
            }
        }
    }

    private static void managePatients(Scanner sc, PatientDAO patientDAO) {
    	while (true) {
        System.out.println("1. Add Patient");
        System.out.println("2. View All Patients");
        System.out.println("3. View Patient by ID");
        System.out.println("4. Update Patient");
        System.out.println("5. Delete Patient");
        System.out.println("6. Exit");
        int patientChoice = sc.nextInt();

        switch (patientChoice) {
        case 1:
			Patient ptu = new Patient();
			System.out.println("Enter Patient ID: ");
			int pid = sc.nextInt();
			sc.nextLine();
			System.out.println("Enter Patient Name: ");
			String pname = sc.nextLine();
			System.out.println("Enter Patient Age: ");
			int age = sc.nextInt();
			sc.nextLine();
			System.out.println("Enter Patient Gender: ");
			String gender = sc.nextLine();
			System.out.println("Enter Contact Number:");
			String phone = sc.nextLine();
			System.out.println("Enter email:");
			String email = sc.nextLine();
			System.out.println("Enter Address:");
			String add = sc.nextLine();
			System.out.println("Enter Medical History of Patient:");
			String his = sc.nextLine();
			System.out.println("Enter Assigned Doctor:");
			String doc = sc.nextLine();
			
			ptu.setPatientId(pid);
			ptu.setPName(pname);		
			ptu.setAge(age);
			ptu.setGender(gender);
			ptu.setPcontactNumber(phone);
			ptu.setPEmail(email);
			ptu.setAddress(add);
			ptu.setMedicalHistory(his);
			ptu.setDoctorAssigned(doc);	
			patientDAO.insertEntity(ptu);
			break;
		case 2:

			List<Patient> records = patientDAO.fetchAllRecords();

			// Print or use the records as needed
			for (Patient record : records) {
				System.out.println(record);
			}
			break;
		case 3:
			System.out.println("Enter id to show the details of the patient:");
			int patientId=sc.nextInt();
			Patient entity = patientDAO.getById(patientId); 
			if (entity != null) {
				System.out.println("Entity found: " + entity);
			} else {
				System.out.println("No entity found with pId."+patientId);
			}
			break;
		case 4:
			System.out.println("Enter id to update the details of the patient:");
			int pid1 = sc.nextInt();
			System.out.println("Enter the updated Name of the patient:");
			String newPatientName=sc.next();
			patientDAO.updateNameById(pid1, newPatientName);
			break;
		case 5:
			System.out.println("Enter id to delete the details of the Patient:");
			int id1 = sc.nextInt();
			patientDAO.deleteById(id1);
			break;
		case 6:
            System.out.println("Exiting from here...");
            return;
            default:
                System.out.println("Invalid choice for managing patients!");
        }
      }
    }

    private static void manageDoctors(Scanner sc, DoctorDAO doctorDAO) {
    	while (true) {
        System.out.println("1. Add Doctor");
        System.out.println("2. View All Doctors");
        System.out.println("3. View Doctor by ID");
        System.out.println("4. Update Doctor Contact Number");
        System.out.println("5. Delete Doctor");
        System.out.println("6. Exit");
        int doctorChoice = sc.nextInt();

        switch (doctorChoice) {
        case 1:
            Doctor doctor = new Doctor();
            System.out.println("Enter Doctor ID:");
            doctor.setDoctorId(sc.nextInt());
            sc.nextLine();  // Consume the leftover newline character

            System.out.println("Enter Name:");
            doctor.setName(sc.nextLine());

            System.out.println("Enter Specialization:");
            doctor.setSpecialization(sc.nextLine());

            System.out.println("Enter Contact Number:");
            doctor.setContactNumber(sc.nextLine());

            System.out.println("Enter Email:");
            doctor.setEmail(sc.nextLine());

            System.out.println("Enter Department:");
            doctor.setDepartment(sc.nextLine());

            doctorDAO.insertEntity(doctor);
            System.out.println("Doctor added successfully!");
            break;


            case 2:
                List<Doctor> doctors = doctorDAO.fetchAllRecords();
                if (doctors.isEmpty()) {
                    System.out.println("No doctors found.");
                } else {
                    for (Doctor doc : doctors) {
                        System.out.println(doc);
                    }
                }
                break;

            case 3:
                System.out.println("Enter Doctor ID to view details:");
                int viewDoctorId = sc.nextInt();
                Doctor fetchedDoctor = doctorDAO.getById(viewDoctorId);
                if (fetchedDoctor != null) {
                    System.out.println("Doctor details: " + fetchedDoctor);
                } else {
                    System.out.println("Doctor with ID " + viewDoctorId + " not found.");
                }
                break;

            case 4:
                System.out.println("Enter Doctor ID to update contact number:");
                int updateDoctorId = sc.nextInt();
                sc.nextLine();
                System.out.println("Enter new contact number:");
                String newContactNumber = sc.nextLine();
                doctorDAO.updateContactNumberById(updateDoctorId, newContactNumber);
                System.out.println("Contact number updated successfully!");
                break;

            case 5:
                System.out.println("Enter Doctor ID to delete:");
                int deleteDoctorId = sc.nextInt();
                doctorDAO.deleteById(deleteDoctorId);
                System.out.println("Doctor deleted successfully!");
                break;
                
            case 6:
                System.out.println("Exiting from here...");
                return;

            default:
                System.out.println("Invalid choice for managing doctors!");
        }
      }
    }


    private static void manageAppointments(Scanner sc, AppointmentDAO appointmentDAO) {
    	while (true) {
        System.out.println("1. Add Appointment");
        System.out.println("2. View All Appointments");
        System.out.println("3. Cancel Appointment");
        System.out.println("4. Exit");
        int appointmentChoice = sc.nextInt();

        switch (appointmentChoice) {
            case 1: // Add Appointment
                Appointment appointment = new Appointment();
                System.out.println("Enter Appointment ID:");
                appointment.setAppointmentId(sc.nextInt());
                System.out.println("Enter Patient ID:");
                appointment.setPatientId(sc.nextInt());
                System.out.println("Enter Doctor ID:");
                appointment.setDoctorId(sc.nextInt());
                sc.nextLine(); // Consume newline

                System.out.println("Enter Appointment Date (YYYY-MM-DD):");
                String dateInput = sc.nextLine();
                try {
                    // Convert string to java.sql.Date
                    java.sql.Date appointmentDate = java.sql.Date.valueOf(dateInput);
                    appointment.setAppointmentDate(appointmentDate);
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid date format! Please try again.");
                    break;
                }

                appointment.setStatus("Confirmed");
                appointmentDAO.insertEntity(appointment);
                System.out.println("Appointment added successfully!");
                break;

            case 2: // View All Appointments
                List<Appointment> appointments = appointmentDAO.fetchAllRecords();
                if (appointments.isEmpty()) {
                    System.out.println("No appointments found.");
                } else {
                    for (Appointment app : appointments) {
                        System.out.println(app);
                    }
                }
                break;

            case 3: // Cancel Appointment
                System.out.println("Enter Appointment ID to cancel:");
                int appointmentId = sc.nextInt();
                appointmentDAO.updateStatusById(appointmentId, "Cancelled");
                System.out.println("Appointment cancelled successfully!");
                break;
                
            case 4:
                System.out.println("Exiting from here...");
                return;

            default:
                System.out.println("Invalid choice for managing appointments!");
        }
      }
    }

    private static void managePrescriptions(Scanner sc, PrescriptionDAO prescriptionDAO) {
    	while (true) {
        System.out.println("1. Add Prescription");
        System.out.println("2. View Prescriptions for Patient");
        System.out.println("3. Exit");
        int prescriptionChoice = sc.nextInt();

        switch (prescriptionChoice) {
            case 1: // Add Prescription
                Prescription prescription = new Prescription();
                System.out.println("Enter Prescription ID:");
                prescription.setPrescriptionId(sc.nextInt());
                System.out.println("Enter Patient ID:");
                prescription.setPatientId(sc.nextInt());
                System.out.println("Enter Doctor ID:");
                prescription.setDoctorId(sc.nextInt());
                sc.nextLine(); // Consume the newline character

                System.out.println("Enter Medicines (comma separated):");
                prescription.setMedicines(sc.nextLine());

                System.out.println("Enter Dosage Instructions:");
                prescription.setDosageInstructions(sc.nextLine());

                prescriptionDAO.insertEntity(prescription);
                System.out.println("Prescription added successfully!");
                break;

            case 2: 
                System.out.println("Enter Patient ID to view prescriptions:");
                int patientId = sc.nextInt();
                List<Prescription> prescriptions = prescriptionDAO.fetchAllRecords(); // Fetch all prescriptions
                boolean found = false;
                for (Prescription pres : prescriptions) {
                    if (pres.getPatientId() == patientId) {
                        System.out.println(pres);
                        found = true;
                    }
                }
                if (!found) {
                    System.out.println("No prescriptions found for the given patient ID.");
                }
                break;
            case 3:
                System.out.println("Exiting from here...");
                return;

            default:
                System.out.println("Invalid choice for managing prescriptions!");
        }
      }
    }

}