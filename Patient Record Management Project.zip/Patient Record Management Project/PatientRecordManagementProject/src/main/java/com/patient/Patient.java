package com.patient;

import javax.persistence.Entity;
import javax.persistence.Id;
//import javax.persistence.Table;

@Entity
//@Table(name = "patient")
public class Patient {
	@Id
	private int patientId;
	private String pName;
    private int age;
    private String gender;
    private String pContactNumber;
    private String pEmail;
    private String address;
    private String medicalHistory;
    private String doctorAssigned;
    //Getters and Setters
    public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getPName() {
		return pName;
	}
	public void setPName(String pName) {
		this.pName = pName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPContactNumber() {
		return pContactNumber;
	}
	public void setPcontactNumber(String pContactNumber) {
		this.pContactNumber = pContactNumber;
	}
	public String getPEmail() {
		return pEmail;
	}
	public void setPEmail(String pEmail) {
		this.pEmail = pEmail;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMedicalHistory() {
		return medicalHistory;
	}
	public void setMedicalHistory(String medicalHistory) {
		this.medicalHistory = medicalHistory;
	}
	public String getDoctorAssigned() {
		return doctorAssigned;
	}
	public void setDoctorAssigned(String doctorAssigned) {
		this.doctorAssigned = doctorAssigned;
	}
	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Patient(int patientId, String pName, int age, String gender, String pContactNumber, String pEmail,
			String address, String medicalHistory, String doctorAssigned) {
		super();
		this.patientId = patientId;
		this.pName = pName;
		this.age = age;
		this.gender = gender;
		this.pContactNumber = pContactNumber;
		this.pEmail = pEmail;
		this.address = address;
		this.medicalHistory = medicalHistory;
		this.doctorAssigned = doctorAssigned;
	}
	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", pName=" + pName + ", age=" + age + ", gender=" + gender
				+ ", pContactNumber=" + pContactNumber + ", pEmail=" + pEmail + ", address=" + address + ", medicalHistory="
				+ medicalHistory + ", doctorAssigned=" + doctorAssigned + "]";
	}
}