package com.patient;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.List;

public class PrescriptionDAO {
    private SessionFactory factory;

    public PrescriptionDAO(SessionFactory factory) {
        this.factory = factory;
    }

    public void insertEntity(Prescription prescription) {
        Session session = factory.openSession();
        Transaction transaction = session.beginTransaction();
        session.save(prescription);
        transaction.commit();
        session.close();
    }

    public List<Prescription> fetchAllRecords() {
        Session session = factory.openSession();
        List<Prescription> records = session.createQuery("from Prescription", Prescription.class).list();
        session.close();
        return records;
    }

    public Prescription getById(int prescriptionId) {
        Session session = factory.openSession();
        Prescription prescription = session.get(Prescription.class, prescriptionId);
        session.close();
        return prescription;
    }

    public void deleteById(int prescriptionId) {
        Session session = factory.openSession();
        Transaction transaction = session.beginTransaction();
        Prescription prescription = session.get(Prescription.class, prescriptionId);
        if (prescription != null) {
            session.delete(prescription);
        }
        transaction.commit();
        session.close();
    }
}