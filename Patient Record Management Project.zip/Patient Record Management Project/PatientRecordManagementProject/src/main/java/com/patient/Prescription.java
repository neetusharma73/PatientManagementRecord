package com.patient;

import javax.persistence.Entity;
import javax.persistence.Id;
//import javax.persistence.Table;

@Entity
//@Table(name = "prescription")
public class Prescription {
    @Id
    private int prescriptionId;
    private int patientId;
    private int doctorId;
    private String medicines; // List of medicines
    private String dosageInstructions; // Instructions for dosage

    // Getters and Setters
    public int getPrescriptionId() {
        return prescriptionId;
    }

    public void setPrescriptionId(int prescriptionId) {
        this.prescriptionId = prescriptionId;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    public String getMedicines() {
        return medicines;
    }

    public void setMedicines(String medicines) {
        this.medicines = medicines;
    }

    public String getDosageInstructions() {
        return dosageInstructions;
    }

    public void setDosageInstructions(String dosageInstructions) {
        this.dosageInstructions = dosageInstructions;
    }

	public Prescription() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Prescription(int prescriptionId, int patientId, int doctorId, String medicines, String dosageInstructions) {
		super();
		this.prescriptionId = prescriptionId;
		this.patientId = patientId;
		this.doctorId = doctorId;
		this.medicines = medicines;
		this.dosageInstructions = dosageInstructions;
	}

	@Override
	public String toString() {
		return "Prescription [prescriptionId=" + prescriptionId + ", patientId=" + patientId + ", doctorId=" + doctorId
				+ ", medicines=" + medicines + ", dosageInstructions=" + dosageInstructions + "]";
	}
    
}